/**
 *
 * @author Team 8
 */
import java.awt.*;
import javax.swing.*;

public class myJPanelNorth extends JPanel{
    
    JButton b1,b2,b3,b4;
    
    public myJPanelNorth(){
        super();
        setBackground(new Color(9,49,98));
        b1 = new JButton("Credits");
        b2 = new JButton("Instructions");
        b3 = new JButton("Characters");
        b4 = new JButton("Map");
        add(b1);
        add(b2);
        add(b3);
        add(b4);
    }
    
}

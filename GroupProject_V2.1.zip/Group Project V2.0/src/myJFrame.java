/**
 *
 * @author Team 8
 */
import java.awt.*;
import javax.swing.*;

public class myJFrame extends JFrame{
    
    myJPanel mjp;
    
    public myJFrame(){
        super("Team 8's Final Project");
        mjp = new myJPanel();
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(mjp);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize (1000,650);
        setVisible(true);
    }
    
}

/**
 *
 * @author jgoode
 */
import java.awt.*;
import javax.swing.*;


public class myJPanelSouth extends JPanel {
    
    JButton character, theme;
    String inCharacter, inTheme;
    
    public myJPanelSouth(String inCharacter, String inTheme){
        setLayout (new GridLayout(1,2));
        character = new JButton("Character: "+inCharacter);
        theme = new JButton("Theme: "+inTheme);
        add(character);
        add(theme);
    }
}

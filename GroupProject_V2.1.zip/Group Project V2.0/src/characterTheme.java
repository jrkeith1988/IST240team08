/**
 *
 * @author Team 8
 */
import java.awt.*;
import javax.swing.*;

public class characterTheme extends JPanel {
    
    characterThemeLeft ctl;
    characterThemeRight ctr;
   
    public characterTheme(){
        setBackground(Color.green);
        setLayout (new GridLayout(1,2));
        ctl = new characterThemeLeft();
        ctr = new characterThemeRight();
        add(ctl);
        add(ctr);   
      
    }
}

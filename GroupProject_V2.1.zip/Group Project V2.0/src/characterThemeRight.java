/**
 *
 * @author Team 8 
 */
import java.awt.*;
import javax.swing.*;


public class characterThemeRight extends JPanel {
    
    JButton characterThemeButton = new JButton("Start Game: Map");
    JLabel jl = new JLabel("Choose your character!");
    JRadioButton jrb1,jrb2,jrb3;
    ButtonGroup character;
    
    public characterThemeRight(){
        setBackground(new Color(249,76,255));
        setLayout(new GridLayout(5,1));
        jrb1 = new JRadioButton("Coach");
        jrb2 = new JRadioButton("Football Player");
        jrb3 = new JRadioButton ("Scholar");
        character = new ButtonGroup();
        character.add(jrb1);
        character.add(jrb2);
        character.add(jrb3);
        jl.setHorizontalAlignment(JTextField.CENTER);
        jl.setFont(new Font("Sarif",Font.PLAIN,25));
        jl.setOpaque(false);
        jrb1.setHorizontalAlignment(JRadioButton.CENTER);
        jrb1.setOpaque(false);
        jrb2.setHorizontalAlignment(JRadioButton.CENTER);
        jrb2.setOpaque(false);
        jrb3.setHorizontalAlignment(JRadioButton.CENTER);
        jrb3.setOpaque(false);
        add(jl);
        add(jrb1);
        add(jrb2);
        add(jrb3);
        add(characterThemeButton);
    }
}

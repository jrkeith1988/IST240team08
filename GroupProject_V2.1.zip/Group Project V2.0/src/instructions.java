/**
 *
 * @author jgoode
 */
import java.awt.*;
import javax.swing.*;

public class instructions extends JPanel{
    
    JButton instructionsButton;
    
    public instructions(){
        setBackground(new Color(76,249,255));
        instructionsButton = new JButton("Instructions Menu: Click to return to main menu.");
        add(instructionsButton);        
    }
    
}

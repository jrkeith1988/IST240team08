/**
 *
 * @author team 8
 */
import java.awt.*;
import javax.swing.*;

public class myJPanelCenter extends JPanel{
    
    ImageIcon icon = new ImageIcon("images/psnl.jpg");
    JLabel label;
    JButton centerButton;
    
    public myJPanelCenter(){
        
        super();
        setLayout(new BorderLayout());
        setBackground(new Color(9,49,98));
        centerButton = new JButton();
        label = new JLabel("Welcome to Team 8's Project Game!");
        label.setForeground(Color.white);
        label.setFont(new Font("Sarif", Font.PLAIN,50));
        add (label, "North");
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setOpaque(false);
        add(centerButton, "Center");
        centerButton.setOpaque(false);
        centerButton.setIcon(icon);
    }
    
}

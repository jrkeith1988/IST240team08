/**
 *
 * @author Team 8
 */
import java.awt.*;
import javax.swing.*;

public class characterThemeLeft extends JPanel {
    
    JButton characterThemeButton = new JButton("Return to main menu.");
    JLabel jl = new JLabel("Choose a theme!");
    JRadioButton jrb1,jrb2,jrb3;
    ButtonGroup theme;
    
    public characterThemeLeft(){
        setBackground(new Color(255,237,76));
        setLayout(new GridLayout(5,1));
        jrb1 = new JRadioButton("Football");
        jrb2 = new JRadioButton("History");
        jrb3 = new JRadioButton("Java");
        theme = new ButtonGroup();
        theme.add(jrb1);
        theme.add(jrb2);
        theme.add(jrb3);
        jl.setHorizontalAlignment(JTextField.CENTER);
        jl.setFont(new Font("Sarif",Font.PLAIN,25));
        jl.setOpaque(false);
        jrb1.setHorizontalAlignment(JRadioButton.CENTER);
        jrb1.setOpaque(false);
        jrb2.setHorizontalAlignment(JRadioButton.CENTER);
        jrb2.setOpaque(false);
        jrb3.setHorizontalAlignment(JRadioButton.CENTER);
        jrb3.setOpaque(false);
        add(jl);
        add(jrb1);
        add(jrb2);
        add(jrb3);
        add(characterThemeButton);
    }
    
}

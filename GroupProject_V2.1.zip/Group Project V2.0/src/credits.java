/**
 *
 * @author Team 8
 */
import java.awt.*;
import javax.swing.*;

public class credits extends JPanel {
    
 JLabel label1, label2, label3, label4, label5;
 JButton creditsButton;
 
 public credits(){
     setBackground(new Color(255,76,130));
     setLayout(new GridLayout(6,1));
     creditsButton = new JButton("Click here to return to main menu!");
     label1 = new JLabel("This game was written by:");
     label1.setFont(new Font("Sarif",Font.PLAIN, 50));
     label2 = new JLabel("Justin Goode: jcg5429");
     label2.setFont(new Font("Sarif",Font.PLAIN,25));
     label3 = new JLabel("Elliott Cook: ejc5478");
     label3.setFont(new Font("Sarif",Font.PLAIN,25));
     label4 = new JLabel("Jay Keith: jpk5816");
     label4.setFont(new Font("Sarif",Font.PLAIN,25));
     label5 = new JLabel("Jason D'Aleo: jdd5469");
     label5.setFont(new Font("Sarif",Font.PLAIN,25));
     add(label1);
     label1.setHorizontalAlignment(JLabel.CENTER);
     add(label2);
     label2.setHorizontalAlignment(JLabel.CENTER);
     add(label3);
     label3.setHorizontalAlignment(JLabel.CENTER);
     add(label4);
     label4.setHorizontalAlignment(JLabel.CENTER);
     add(label5);
     label5.setHorizontalAlignment(JLabel.CENTER);
     add(creditsButton);   
 }
    
}

/**
 *
 * @author jgoode
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class myJPanel extends JPanel implements ActionListener {
    
    credits credits;
    instructions instructions;
    characterTheme characterTheme;
    map map;
    myJPanelCenter MJPCenter;
    myJPanelNorth MJPNorth;
    myJPanelSouth MJPSouth;
    String theme = "Football";
    String character = "Coach";
    
    public myJPanel(){
        super();
        setBackground(Color.white);
        setLayout (new BorderLayout());
        credits = new credits();
        instructions = new instructions();
        characterTheme = new characterTheme();
        map = new map();
        MJPCenter = new myJPanelCenter();
        MJPSouth = new myJPanelSouth(theme, character);
        MJPNorth = new myJPanelNorth();
        add(MJPNorth, "North");
        add(MJPCenter,"Center");
        add(MJPSouth,"South");
        MJPNorth.b1.addActionListener(this);
        MJPNorth.b2.addActionListener(this);
        MJPNorth.b3.addActionListener(this);
        MJPNorth.b4.addActionListener(this);
        credits.creditsButton.addActionListener(this);
        instructions.instructionsButton.addActionListener(this);
        map.mapButton.addActionListener(this);
        characterTheme.ctl.jrb1.addActionListener(this);
        characterTheme.ctl.jrb2.addActionListener(this);
        characterTheme.ctl.jrb3.addActionListener(this);
        characterTheme.ctl.characterThemeButton.addActionListener(this);
        characterTheme.ctr.jrb1.addActionListener(this);
        characterTheme.ctr.jrb2.addActionListener(this);
        characterTheme.ctr.jrb3.addActionListener(this);
        characterTheme.ctr.characterThemeButton.addActionListener(this);
    }
    @Override
    public void actionPerformed (ActionEvent ae){
        Object obj = ae.getSource();
        
        if (obj == MJPNorth.b1){
            removeAll();
            add(credits);
            validate();
            repaint();
        }
        else if (obj == MJPNorth.b2){
            removeAll();
            add(instructions);
            validate();
            repaint();           
        }
        else if (obj == MJPNorth.b3){
            removeAll();
            add(characterTheme);
            validate();
            repaint();
        }
        else if (obj == MJPNorth.b4){
            removeAll();
            add(map);
            validate();
            repaint();           
        }
        else if (obj == credits.creditsButton){
            removeAll();
            add(MJPNorth, "North");
            add(MJPCenter, "Center");
            add(MJPSouth, "South");
            validate();
            repaint();
        }
        else if (obj == instructions.instructionsButton){
            removeAll();
            add(MJPNorth, "North");
            add(MJPCenter, "Center");
            add(MJPSouth, "South");
            validate();
            repaint();
        }
        else if (obj == map.mapButton){
            removeAll();
            add(MJPNorth, "North");
            add(MJPCenter, "Center");
            add(MJPSouth, "South");
            validate();
            repaint();
        }
        else if (obj == characterTheme.ctl.characterThemeButton){
            removeAll();
            add(MJPNorth, "North");
            add(MJPCenter, "Center");
            add(MJPSouth, "South");
            validate();
            repaint();
        }
        else if (obj == characterTheme.ctr.characterThemeButton){
            removeAll();
            add(map);
            validate();
            repaint();
        }
    }
            
    
}

/**
 *
 * @author jgoode
 */
import java.awt.*;
import javax.swing.*;

public class map extends JPanel {
    
    JButton mapButton;
    JLabel background;
    ImageIcon img;
    
    
    public map(){
        setBackground(new Color(76,255,130));
        setLayout(new BorderLayout());
        background = new JLabel(new ImageIcon("images/pennmap.jpg"));
        add (background);
        background.setLayout(null);
        mapButton = new JButton("Map Menu: Click to return to main menu.");
        background.add(mapButton);
        mapButton.setBounds(new Rectangle(300,20,300,50));
        
    }
    
    
}
